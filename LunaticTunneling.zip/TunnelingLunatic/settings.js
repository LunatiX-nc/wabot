//base by Andyyuda
//recode by andyyuda
// terecode by Lunatic
//Telegram: t.me/6285955333616

const fs = require('fs')
const chalk = require('chalk')

//owmner v card
global.ytname = "Lunatic" //ur yt chanel name
global.socialm = "tunnelingLunatic" //ur github or insta name
global.location = "Indonesia" //ur location

//new
global.botname = 'AndyStore ʙᴏᴛ' //ur bot name
global.ownernumber = '6285955333616' //ur owner number
global.ownername = 'Lunatic' //ur owner name
global.websitex = "wa.me/6285955333616"
global.wagc = "https://chat.whatsapp.com/GCYeQJsBu5JElcVZX2owQQ"
global.themeemoji = '🪀'
global.wm = "AndyStore ʙᴏᴛ"
global.botscript = 'https://whatsapp.com/channel/0029VaFPqF01yT2IK1I8DV1T' //script link
global.packname = "Lunatic ʙᴏᴛ"
global.author = "TunnelingLunatic"
global.creator = "6285955333616@s.whatsapp.net"
global.xprefix = '.'
global.premium = ["6285955333616"] // Premium User
global.hituet = 0

//
global.domain = 'pro-tunnel.me'
//global.tokendo = 'dop_v1_779b736682a2d171d8cb7c2f3d526f2b508ee551ac066047694505972548644e'
//bot sett
global.typemenu = 'v10' // menu type 'v1' => 'v8'
global.typereply = 'v1' // reply type 'v1' => 'v3'
global.autoblocknumber = '' //set autoblock country code
global.antiforeignnumber = '' //set anti foreign number country code
global.welcome = false //welcome/left in groups
global.anticall = false //bot blocks user when called
global.autoswview = true //auto status/story view
global.adminevent = false //show promote/demote message
global.groupevent = false //show update messages in group chat
//msg
global.mess = {
	limit: 'Your limit is up!',
	nsfw: 'Nsfw is disabled in this group, Please tell the admin to enable',
    done: 'Done✓',
    error: 'Error!',
    success: 'Succes'
}
//thumbnail
global.thumb = fs.readFileSync('./XeonMedia/theme/klmpk.jpg')

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update'${__filename}'`))
    delete require.cache[file]
    require(file)
})