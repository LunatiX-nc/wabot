const path = require('path');
const fs = require('fs');

// Path relatif untuk memuat vps.json
const vpsFilePath = path.resolve(__dirname, 'vps.json');
let vpsList = require(vpsFilePath); // Impor data VPS dari vps.json

function getVPS(vpsId) {
    const vps = vpsList.find(vps => vps.id === vpsId);
    if (!vps) {
        throw new Error(`VPS dengan ID '${vpsId}' tidak ditemukan.`);
    }
    return vps;
}

function vpsExists(vpsId) {
    return vpsList.some(vps => vps.id === vpsId);
}

function addVPS(vpsId, host, port, username, password, domain) {
    if (vpsExists(vpsId)) {
        throw new Error(`VPS dengan ID '${vpsId}' sudah ada.`);
    }
    const newVPS = { id: vpsId, host, port, username, password, domain };
    vpsList.push(newVPS);
    saveVPSToFile(); // Simpan perubahan ke file vps.json setelah menambah VPS baru
}

function deleteVPS(vpsId) {
    const initialLength = vpsList.length;
    vpsList = vpsList.filter(vps => vps.id !== vpsId);
    if (vpsList.length === initialLength) {
        throw new Error(`VPS dengan ID '${vpsId}' tidak ditemukan.`);
    }
    saveVPSToFile(); // Simpan perubahan ke file vps.json setelah menghapus VPS
}

function saveVPSToFile() {
    fs.writeFileSync(vpsFilePath, JSON.stringify(vpsList, null, 2));
}

module.exports = {
    getVPS,
    addVPS,
    vpsExists,
    deleteVPS
};